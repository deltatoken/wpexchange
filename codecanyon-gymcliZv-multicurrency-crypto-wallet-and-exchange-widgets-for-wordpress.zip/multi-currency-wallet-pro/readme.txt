=== Multi Currency Wallet ===
Contributors: noxonsu, burdianov
Tags: adress generation, bitcoin, blockchain, crypto, cryptocurrency, eos, ethereum, exchange, shortcode, wallet, widget
Requires at least: 5.0
Tested up to: 5.5
Stable tag: 1.0.2
Requires PHP: 5.6
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Simplest Multi-currency wallet for WordPress.

== Description ==

Simplest Multi-currency wallet for WordPress. Check premium version https://codecanyon.net/item/multicurrency-crypto-wallet-and-exchange-widgets-for-wordpress/23532064

We use this 3rd party services:
https://etherscan.io/ - free public blockchain explorer. they provide information for user balances (Ethereum cryptoccurrency and ER20 assets);
https://insight.bitpay.com  - free bitcoin endpoint where we send a transactions for broadcatst to the bitcoin network. Otherwise user must install own bitcoin node.
https://infura.io/  - (free 100,000 Requests/Day) ethereum endoint to broadcast transactions.

== Usage ==

Copy and paste this shortcode in your page content.
[mcwallet_widget]

Or add this code to the place of the template where you need to display widget.
`<?php echo do_shortcode( '[mcwallet_widget]' );?>`

== Frequently Asked Questions ==

= Can i add my own token? =

Yes, you can!.

== Screenshots ==

1. https://growup.wpmix.net/swap-docs/screenshots/admin-1.jpg
2. https://growup.wpmix.net/swap-docs/screenshots/admin-2.jpg

== Changelog ==

= 1.0.0 =
* Release

